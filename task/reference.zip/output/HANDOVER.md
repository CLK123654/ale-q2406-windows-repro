# 发布窗口处理摘要

input_data目录包含通道、窗口、排队请求和事务计划。

使用tools/build_delivery.py连接空数据库。results目录保存事务、最终窗口、排队决定、冲突及边界结果。handover.json状态为READY时，可继续本批排程。
